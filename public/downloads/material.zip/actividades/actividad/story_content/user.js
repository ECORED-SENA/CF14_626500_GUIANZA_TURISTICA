function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6moxWc1ZvZb":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

